# tooru-ink

这是我的个人主页源码以及GitHub Pages托管仓库, 我的主页地址:https://tooru.ink

由于最开始只是想写个动画玩玩 因此项目结构可能有些乱 如果是想要树叶飘落效果, 可以直接提取statics/scripts目录下的fall.js 使用方法可查看index.html
